from django.apps import AppConfig


class SmsappConfig(AppConfig):
    name = 'smsapp'
